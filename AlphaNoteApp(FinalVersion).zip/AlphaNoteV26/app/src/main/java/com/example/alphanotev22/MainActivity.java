package com.example.alphanotev22;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ListView;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Note> noteArrayList;
    private ListView listView;
    private NotesAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        loadNotes();

        listView = findViewById(R.id.lv_notes);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, NoteActivity.class);
                intent.putExtra("noteID", -1); //-1 code for new note
                startActivityForResult(intent, 145);//request code 145 for receiving back the result
            }
        });

        if (noteArrayList==null) {
            noteArrayList = new ArrayList<>();
        }
        //setting the adapter
        adapter = new NotesAdapter(this, noteArrayList);
        listView.setAdapter(adapter);

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Are you sure you want to delete this note?")
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setMessage("You can delete the note you selected by pressing Yes or dismiss by pressing No")
                        .setNegativeButton("No", null)
                        .setPositiveButton("Yes",new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int which) {
                                noteArrayList.remove(position);
                                adapter.notifyDataSetChanged();
                            }
                        }).show();
                return true;
            }
        });
        //click listener for item
        //this is for view&edit an existing note
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(MainActivity.this, NoteActivity.class);
                intent.putExtra("noteID", i);//the index of the note for editing
                Note note = adapter.getItem(i);//get the current item to edit
                intent.putExtra("edit_note", note); //put the item on the intent and pass it to the NotesActivity
                startActivityForResult(intent, 145);//request code 145 for receiving back the result
            }
        });
    }

    //in this method you will get the result back from the NotesActivity
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //this is the case that we get back a result (including a note)
        if (requestCode == 145 && resultCode == RESULT_OK) {
            //check if the received data (which is an intent) has extra with the name "new_note"
            if (data.hasExtra("new_note")) {
                Note newNote = data.getParcelableExtra("new_note");
                noteArrayList.add(newNote);//add the newNote to the current ArrayList
                adapter.notifyDataSetChanged();//update the adapter
            }
            //check if the received data (which is an intent) has extra with the name "updated_note"
            if (data.hasExtra("updated_note")) {
                Note updatedNote = data.getParcelableExtra("updated_note");
                int index = data.getIntExtra("noteID", -1);//get the index of the note to update
                noteArrayList.set(index, updatedNote);//add the newNote to the current ArrayList
                adapter.notifyDataSetChanged();//update the adapter
            }

        }
    }

    //shared preferences used with help of Gson gradle to save and load objects in array.
    private void saveNotes() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(noteArrayList);
        editor.putString("note list", json);
        editor.apply();
    }

    private void loadNotes() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("note list", null);
        Type type = new TypeToken<ArrayList<Note>>() {
        }.getType();
        noteArrayList = gson.fromJson(json, type);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_info_main){
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Copyright information")
                    .setIcon(android.R.drawable.ic_menu_info_details)
                    .setMessage("This android application prototype has been completed by Alexandros Christoforos Mitronikas as a software project for City Unity college and Cardiff Metropolitan University.")
                    .setNeutralButton("OK", new DialogInterface.OnClickListener(){
                        @Override
                        public void onClick(DialogInterface dialogInterface, int which) {
                            dialogInterface.dismiss();
                        }
                    }).show();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStop() {
        super.onStop();
        saveNotes();
    }
}
