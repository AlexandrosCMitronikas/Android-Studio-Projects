package com.example.alphanotev22;

import java.util.ArrayList;

public class DataTool {

    public static ArrayList<Note> getNotes() {
       ArrayList<Note> notesList = new ArrayList();

        notesList.add(new Note("This is a title", "And this is the content.. bla blab l b lal a bv l la b la"));



        return notesList;
    }

}
