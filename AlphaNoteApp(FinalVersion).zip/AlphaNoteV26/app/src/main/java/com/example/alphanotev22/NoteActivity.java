package com.example.alphanotev22;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class NoteActivity extends AppCompatActivity {
    int noteID;
    private EditText noteTitle;
    private EditText noteText;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);

        noteTitle = findViewById(R.id.noteTitle);
        noteText = findViewById(R.id.noteEditText);

        Intent intent = getIntent();
        noteID = intent.getIntExtra("noteID", -1);

        if (noteID != -1){ //means that we are in EditNote mode
            //get the data from the intent and put them into the edit texts
            if (intent.hasExtra("edit_note")) {
                Note note = intent.getParcelableExtra("edit_note");
                noteTitle.setText(note.getTitle());
                noteText.setText(note.getContent());
            }
        }
        else{ //means that we are in NewNote mode
            noteTitle.setText("");
            noteText.setText("");
        }

    }


    //I have added a menu here for the "Save" action so you don't need the button
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_note, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_save) {
            //check first what is the mode
            if (noteID!=-1) {//it means we are in edit mode
                saveNoteAndReturn("updated_note");

            } else {//it means we are in newNote mode
                saveNoteAndReturn("new_note");


            }
            return true;
        }
        //if you have other menu actions for this activity you can add them here

        return super.onOptionsItemSelected(item);
    }

    //helper method for the save+exit action
    //if action="new_note it will pass a new note back
    //if action="updated_note" t will pass an edited note back
    private void saveNoteAndReturn(String action) {
        String title = noteTitle.getText().toString().trim();
        String content = noteText.getText().toString().trim();

        //logic to check if both are empty (gives error)
        if (title.isEmpty() && content.isEmpty()){
            new AlertDialog.Builder(NoteActivity.this)
                    .setTitle("Information missing")
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .setMessage("A note with no context can not be saved.")
                    .setNeutralButton("OK", new DialogInterface.OnClickListener(){
                        @Override
                        public void onClick(DialogInterface dialogInterface, int which) {
                            dialogInterface.dismiss();
                        }
                    }).show();
        }else {
            Note note = new Note(title, content);//if the data aro OK create a note object

            //get the current intent and put the result in
            //this will be transferred to the MainActivity when NotesActivity finishes itself
            Intent intent = getIntent();
            intent.putExtra(action, note); //your whole Note object is inserted as extra (because it is Parcelable)
            intent.putExtra("noteID", noteID);//the note ID is also passed back
            setResult(RESULT_OK, intent);
            finish();
        }
    }
}


